//
//  EditViewController.m
//  BusinessContact
//
//  Created by logicstree-iphone on 30/03/18.
//  Copyright © 2018 ios. All rights reserved.
//

#import "EditViewController.h"
#import "contactDataAccess.h"
#import "AppDelegate.h"

@interface EditViewController ()

@end

@implementation EditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    contactDataAccess *contObj=[contactDataAccess getInstance];
    NSArray * dataBaseArray = [contObj getContactList:[NSString stringWithFormat:@"select * from contact where ID=%@",appDelegate().contactIDs]];
    
    for (int i=0; i<dataBaseArray.count; i++)
    {
        if ([[[dataBaseArray objectAtIndex:i]valueForKey:@"ID"] isEqual:appDelegate().contactIDs])
        {
            _TxtName.text = [[dataBaseArray objectAtIndex:i]valueForKey:@"name"];
            _TxtPhone.text = [[dataBaseArray objectAtIndex:i]valueForKey:@"phone"];
            _TxtEmail.text = [[dataBaseArray objectAtIndex:i]valueForKey:@"email"];
            _TxtAddress.text = [[dataBaseArray objectAtIndex:i]valueForKey:@"address"];
            _TxtCity.text = [[dataBaseArray objectAtIndex:i]valueForKey:@"city"];
        }
    }
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnBackAction:(id)sender
{
    [self.view endEditing:YES];
    
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark- UIButton Action

- (IBAction)editContactAction:(id)sender
{
    [self EditContact];
}

-(void)EditContact
{
    contactDetails *contactModel=[[contactDetails alloc]init];
    
    contactModel.name =  _TxtName.text;
    contactModel.phone =  _TxtPhone.text;
    contactModel.email =  _TxtEmail.text;
    contactModel.address =  _TxtAddress.text;
    contactModel.city =  _TxtCity.text;
    contactModel.ID = appDelegate().contactIDs;
    
    contactDataAccess *contObj=[contactDataAccess getInstance];
    NSString *exitsOrNot=[NSString stringWithFormat:@"select * from contact where ID='%@'",contactModel.ID];
    
    BOOL results = [contObj recordExitsOrNot:exitsOrNot];
    
    if (results == YES)
    {
        [contObj updateData:contactModel];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
