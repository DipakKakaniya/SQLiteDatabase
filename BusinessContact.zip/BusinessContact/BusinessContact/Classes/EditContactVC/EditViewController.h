//
//  EditViewController.h
//  BusinessContact
//
//  Created by logicstree-iphone on 30/03/18.
//  Copyright © 2018 ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *TxtName;
@property (strong, nonatomic) IBOutlet UITextField *TxtAddress;
@property (strong, nonatomic) IBOutlet UITextField *TxtPhone;
@property (strong, nonatomic) IBOutlet UITextField *TxtEmail;
@property (strong, nonatomic) IBOutlet UITextField *TxtCity;

@end
