//
//  ViewController.m
//  BusinessContact
//
//  Created by logicstree-iphone on 30/03/18.
//  Copyright © 2018 ios. All rights reserved.
//

#import "ViewController.h"
#import "contactDataAccess.h"
#import "ContactCell.h"
#import "AppDelegate.h"

@interface ViewController ()
{
     NSArray * dataBaseArray;
}
@end

@implementation ViewController
@synthesize tblContact;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self displayDatabaseDate];
    
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self displayDatabaseDate];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnAddContactAction:(id)sender
{
    [self performSegueWithIdentifier:@"segueAddContact" sender:nil];
}


#pragma mark - UITableView DataSource & Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataBaseArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ContactCell *objCell = (ContactCell*)[tableView dequeueReusableCellWithIdentifier:@"ContactCell"];
    
    objCell.Name.text = [[[dataBaseArray objectAtIndex:indexPath.row]valueForKey:@"name"]uppercaseString];
    objCell.Address.text = [[dataBaseArray objectAtIndex:indexPath.row]valueForKey:@"address"];
    objCell.Phone.text = [[dataBaseArray objectAtIndex:indexPath.row]valueForKey:@"phone"];
    objCell.Email.text = [[dataBaseArray objectAtIndex:indexPath.row]valueForKey:@"email"];
    objCell.City.text = [[dataBaseArray objectAtIndex:indexPath.row]valueForKey:@"city"];
 
    return objCell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   appDelegate().contactIDs = [[dataBaseArray objectAtIndex:indexPath.row]valueForKey:@"ID"];
   [self performSegueWithIdentifier:@"segueEditContact" sender:nil];

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    return YES;
}

- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewRowAction *editAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"Delete " handler:^(UITableViewRowAction *action, NSIndexPath *indexPath)
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Delete" message:@"Are you sure want to delete this contact..!!" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action)
                             {
                                 contactDataAccess *contObj=[contactDataAccess getInstance];
                                 [contObj deleteRecordFromTable:[NSString stringWithFormat:@"DELETE FROM contact WHERE ID = %@",[[dataBaseArray objectAtIndex:indexPath.row]valueForKey:@"ID"]]];
                                 [self displayDatabaseDate];
                             }];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        [alert addAction:cancel];
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
    }];
    
    editAction.backgroundColor = [UIColor grayColor];
    
    return @[editAction];

}


-(void)displayDatabaseDate
{
    contactDataAccess *contObj=[contactDataAccess getInstance];
    dataBaseArray = [contObj getContactList:@"select * from contact"];
    [tblContact setDataSource:self];
    [tblContact setDelegate:self];
    [tblContact reloadData];
}
@end
