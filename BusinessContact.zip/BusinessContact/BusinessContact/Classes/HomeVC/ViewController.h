//
//  ViewController.h
//  BusinessContact
//
//  Created by logicstree-iphone on 30/03/18.
//  Copyright © 2018 ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tblContact;


@end

