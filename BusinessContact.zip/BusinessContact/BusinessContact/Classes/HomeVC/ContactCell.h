//
//  ContactCell.h
//  BusinessContact
//
//  Created by logicstree-iphone on 30/03/18.
//  Copyright © 2018 ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *Name;
@property (strong, nonatomic) IBOutlet UILabel *Address;
@property (strong, nonatomic) IBOutlet UILabel *Phone;
@property (strong, nonatomic) IBOutlet UILabel *Email;
@property (strong, nonatomic) IBOutlet UILabel *City;


@end
