//
//  AddContactVC.m
//  BusinessContact
//
//  Created by logicstree-iphone on 30/03/18.
//  Copyright © 2018 ios. All rights reserved.
//

#import "AddContactVC.h"
#import "contactDataAccess.h"
#import "contactDetails.h"
#import "utils.h"

@interface AddContactVC ()

@end

@implementation AddContactVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBackAction:(id)sender
{
    [self.view endEditing:YES];
    
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)AddContact
{
    contactDetails *contactModel=[[contactDetails alloc]init];
    
    contactModel.name = _TxtName.text;
    contactModel.address = _TxtAddress.text;
    contactModel.phone = _TxtPhone.text;
    contactModel.email = _TxtEmail.text;
    contactModel.city = _TxtCity.text;
    
    contactDataAccess *contObj=[contactDataAccess getInstance];

    NSLog(@"INSERT");
    [contObj insertData:contactModel];
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark- UIButton Action

- (IBAction)addContactAction:(id)sender
{
    [self.view endEditing:YES];
    
    if ([_TxtName.text isEqual:@""])
    {
        [utils showTitle:@"" withMessage:@"Please enter name..!!"];
    }
    else if ([_TxtPhone.text isEqual:@""])
    {
        [utils showTitle:@"" withMessage:@"Please enter phone..!!"];
    }
    else
    {
        [self AddContact];
    }
}

@end
