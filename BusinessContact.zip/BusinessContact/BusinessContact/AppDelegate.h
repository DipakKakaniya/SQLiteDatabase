//
//  AppDelegate.h
//  BusinessContact
//
//  Created by logicstree-iphone on 30/03/18.
//  Copyright © 2018 ios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

AppDelegate *appDelegate(void);

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic,strong) NSString *databasePath;

@property (strong, nonatomic) NSString * contactIDs;

@end

