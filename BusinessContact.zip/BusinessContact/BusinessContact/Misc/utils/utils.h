//
//  utils.h
//  CMMOS
//
//  Created by logicstree-iphone on 10/06/17.
//  Copyright © 2017 ios. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface utils : NSObject

+(BOOL) validateEmail:(NSString*) emailAddress;

+(void)showTitle:(NSString*)title withMessage:(NSString *)message;

+(NSString *) getFilePath :(NSString *)fileName;

+(void) copyFile:(NSString *)file;

+(NSString *) getDatabasePath;

+ (id)saveGetObjectForKey:(NSString *)key;

+ (void)saveSetObject:(id)object forKey:(NSString *)key;


@end
