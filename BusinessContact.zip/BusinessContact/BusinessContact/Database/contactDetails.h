//
//  contactDetails.h
//  CMMOS
//
//  Created by logicstree-iphone on 20/06/17.
//  Copyright © 2017 ios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface contactDetails : NSObject

@property (nonatomic,strong) NSString *ID;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *address;
@property (nonatomic,strong) NSString *phone;
@property (nonatomic,strong) NSString *email;
@property (nonatomic,strong) NSString *city;

@end
