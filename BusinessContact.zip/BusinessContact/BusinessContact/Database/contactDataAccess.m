//
//  contactDataAccess.m
//  CMMOS
//
//  Created by logicstree-iphone on 20/06/17.
//  Copyright © 2017 ios. All rights reserved.
//  https://www.sitepoint.com/getting-started-sqlite3-basic-commands/
//

#import "contactDataAccess.h"
#import "contactDetails.h"
#import "utils.h"

@implementation contactDataAccess

static contactDataAccess *instance=nil;
@synthesize database=_database;

+(contactDataAccess *) getInstance
{
    
    if(!instance)
    {
        instance=[[contactDataAccess alloc]init];
        instance.database=[FMDatabase databaseWithPath:[utils getFilePath:@"contact.db"]];
    }
    return instance;
}

-(BOOL)updateData:(contactDetails *)contact
{
    [instance.database open];
    
    BOOL isUpdated=[instance.database executeUpdate: @"UPDATE contact SET name= ? ,address= ? ,phone= ? , email= ? ,city= ? where ID= ? ",contact.name,contact.address,contact.phone,contact.email,contact.city,contact.ID];
   
    [instance.database close];
    
    return isUpdated;
}

-(BOOL) insertData:(contactDetails *)contact
{
    // insert Contact into database
    
    [instance.database open];
   
    BOOL isInserted=[instance.database executeUpdate:@"INSERT INTO contact (name,address,phone,email,city)  VALUES (?,?,?,?,?);",contact.name,contact.address,contact.phone,contact.email,contact.city];

    [instance.database close];
    
    return isInserted;
}


#pragma mark- DeleteAllTableData

-(BOOL)deleteRecordFromTable:(NSString *)deleteQuery
{
    [instance.database open];
    
    BOOL isDeleted=[instance.database executeUpdate:deleteQuery];
    
    [instance.database close];
    
    return isDeleted;

}

#pragma mark- Check RecordExitsOrNot

-(BOOL) recordExitsOrNot:(NSString *)Query
{
    [instance.database open];
    
    BOOL isCheck=[instance.database recordExistOrNot:Query];
    
    [instance.database close];
    
    return isCheck;
}

#pragma mark- GetContactList

-(NSMutableArray *) getContactList:(NSString*)Query
{
    NSMutableArray *contactList = [[NSMutableArray alloc] init];
    
    FMDatabase *db = [FMDatabase databaseWithPath:[utils getDatabasePath]];
    
    [db open];
    
    FMResultSet *results = [db executeQuery:Query];
    
    while([results next])
    {
        contactDetails *contact = [[contactDetails alloc] init];
        
        contact.ID = [results stringForColumn:@"ID"];
        contact.name = [results stringForColumn:@"name"];
        contact.address = [results stringForColumn:@"address"];
        contact.phone = [results stringForColumn:@"phone"];
        contact.email = [results stringForColumn:@"email"];
        contact.city = [results stringForColumn:@"city"];
        
        [contactList addObject:contact];
    }
    
    [db close];
    
    return contactList;
}


#pragma mark- DisplayDataContact


-(void)displayDataContact
{
    [instance.database open];
    FMResultSet *resultSet=[instance.database executeQuery:@"SELECT * FROM contact"];
    if(resultSet)
    {
        while([resultSet next])
            
        NSLog(@"ContactList");
    }
    [instance.database close];
}

@end


