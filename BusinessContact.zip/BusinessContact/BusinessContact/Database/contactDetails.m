//
//  contactDetails.m
//  CMMOS
//
//  Created by logicstree-iphone on 20/06/17.
//  Copyright © 2017 ios. All rights reserved.
//

#import "contactDetails.h"

@implementation contactDetails

@synthesize ID, name, address, phone, email, city;


@end
