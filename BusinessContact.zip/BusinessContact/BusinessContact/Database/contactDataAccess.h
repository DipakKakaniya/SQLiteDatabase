//
//  contactDataAccess.h
//  CMMOS
//
//  Created by logicstree-iphone on 20/06/17.
//  Copyright © 2017 ios. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "FMResultSet.h"
#import "contactDetails.h"
#import <sqlite3.h>
#import "AppDelegate.h"

@interface contactDataAccess : NSObject
{
    sqlite3 *dbsql;
    AppDelegate *deli;
}

@property (nonatomic,strong) FMDatabase *database;


+(contactDataAccess *) getInstance;

-(void) displayDataContact;
-(BOOL) insertData:(contactDetails *)contact;
-(BOOL) updateData:(contactDetails *)contact;
-(BOOL) recordExitsOrNot:(NSString *)Query;

//Delete
-(BOOL) deleteRecordFromTable:(NSString *)deleteQuery;

//GetDate
-(NSMutableArray *) getContactList:(NSString*)Query;
@end
